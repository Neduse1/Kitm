const defaultData = ["Andrew", "Robert", "Steve"];
let vipList = [];

function checkLocalStorage(){
    return localStorage.getItem("vipList") !== null
}

function loadFromLocalStorage(){
    vipList = JSON.parse(localStorage.getItem("vipList"));
}
function loadFromFile(file) {
    const reader = new FileReader();
}

reader.onload = function(e) {
    const contents = e.target.result;
    vipList = contents.split("\n");
};
reader.readAsText(file);

function sortvipList () {
    vipList.sort();
}
function exportToFile(){
  const filename = "vip_list.txt";
  const text = vipList.join("\n");
  const blob = new Blob([text],{type: "text/plain"});

  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = filename;
  link.click();
}